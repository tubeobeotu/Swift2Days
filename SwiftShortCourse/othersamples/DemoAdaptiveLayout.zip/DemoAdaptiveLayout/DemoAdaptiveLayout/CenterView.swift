//
//  CenterView.swift
//  DemoAdaptiveLayout
//
//  Created by Trinh Minh Cuong on 10/13/14.
//  Copyright (c) 2014 Techmaster Vietnam. All rights reserved.
//

import UIKit

class CenterView: UIViewController {

}
